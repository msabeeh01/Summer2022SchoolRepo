/*Assignment 2, 
Express Portfolio
 Muhammad Sabeeh - 301184564 - 2022/06/16*/

module.exports = 
{
    //"URI": "mongodb://localhost/book_store"
    "URI": "mongodb+srv://Sabeeh:umeriscute123@cluster0.hado6.mongodb.net/?retryWrites=true&w=majority",
    "Secret": 'SomeSecret'
}